Welcome to Multiple Selects.

-- SUMMARY --

Multiple Selects provides a widget for the the following fields types:

- entity_reference
- node_reference
- user_reference
- taxonomy_term_reference
- list_integer
- list_float
- list_text

Rather than having a multi-select field, this modules allows you to have
multiple select fields with the traditional FieldAPI 'Add another item' button.

-- REQUIREMENTS --

options


-- INSTALLATION --

Install as usual, see http://drupal.org/node/70151 for further information.
